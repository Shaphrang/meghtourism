import { getServerClient } from "@/lib/supabaseClients";
import ProfileForm from "./profile-form";

export const dynamic = "force-dynamic";

export default async function AgencyProfilePage() {
  const supabase = getServerClient();
  const { data: { user } } = await supabase.auth.getUser();
  const { data: agency } = await supabase
    .from("tourism_agencies")
    .select("*")
    .eq("owner_user_id", user?.id ?? "")
    .single();

  return <ProfileForm agency={agency} />;
}
