export const revalidate = 300;

export default async function PublicItinsPage() {
  const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL ?? ""}/api/public/itineraries`,
    { next: { revalidate: 300 } });
  const { items } = await res.json();

  return (
    <main className="mx-auto max-w-5xl p-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {items.map((it: any) => (
        <article key={it.id} className="rounded-2xl border p-3">
          <div className="text-sm font-semibold mb-1">{it.title}</div>
          {/* Add <Image> here for cover_image if you store it */}
        </article>
      ))}
    </main>
  );
}
