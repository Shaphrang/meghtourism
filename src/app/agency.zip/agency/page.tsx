import { getServerClient } from "@/lib/supabaseClients";
import { redirect } from "next/navigation";

export const dynamic = "force-dynamic";

export default async function AgencyDashboard() {
  const supabase = getServerClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/agency/login");

  // fetch your agency row once
  const { data: agency } = await supabase
    .from("tourism_agencies")
    .select("id,name,slug")
    .eq("owner_user_id", user.id)
    .single();

  if (!agency) return <main className="p-6">No agency row found.</main>;

  // concurrent counts
  const [i, r, t, p] = await Promise.all([
    supabase.from("itineraries").select("id", { count: "exact", head: true }).eq("provider_id", agency.id),
    supabase.from("rentals").select("id", { count: "exact", head: true }).eq("provider_id", agency.id),
    supabase.from("thrills").select("id", { count: "exact", head: true }).eq("provider_id", agency.id),
    supabase.from("itineraries").select("id", { count: "exact", head: true }).eq("provider_id", agency.id).eq("approval_status","pending"),
  ]);

  return (
    <main className="p-6 space-y-4">
      <header>
        <h1 className="text-xl font-bold">Welcome, {agency.name}</h1>
        <p className="text-sm text-gray-600">Slug: <code className="bg-gray-100 px-1 py-0.5 rounded">{agency.slug}</code></p>
      </header>

      <section className="grid grid-cols-2 gap-3">
        <Card title="Itineraries" value={i.count ?? 0} href="/agency/itineraries" />
        <Card title="Rentals" value={r.count ?? 0} href="/agency/rentals" />
        <Card title="Thrills" value={t.count ?? 0} href="/agency/thrills" />
        <Card title="Pending approvals" value={p.count ?? 0} href="/agency/itineraries" />
      </section>

      <div className="space-x-2">
        <a className="inline-block rounded-xl bg-gray-900 text-white px-4 py-2" href="/agency/itineraries">Add itinerary</a>
        <a className="inline-block rounded-xl bg-gray-900 text-white px-4 py-2" href="/agency/rentals">Add rental</a>
        <a className="inline-block rounded-xl bg-gray-900 text-white px-4 py-2" href="/agency/thrills">Add thrill</a>
        <a className="inline-block rounded-xl border px-4 py-2" href="/agency/profile">Edit profile</a>
      </div>
    </main>
  );
}

function Card({ title, value, href }: { title: string; value: number; href: string }) {
  return (
    <a href={href} className="rounded-2xl border p-4 shadow-sm hover:shadow">
      <div className="text-sm text-gray-600">{title}</div>
      <div className="text-2xl font-semibold">{value}</div>
    </a>
  );
}
