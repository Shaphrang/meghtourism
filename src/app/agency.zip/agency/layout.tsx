import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { getServerClient } from "@/lib/supabaseClients";

export const metadata: Metadata = { title: "Agency • Meghtourism" };
// Private pages must be dynamic (no caching)
export const dynamic = "force-dynamic";

export default async function AgencyLayout({ children }: { children: React.ReactNode }) {
  const supabase = getServerClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/agency/login");
  return <div className="min-h-dvh bg-white text-gray-900">{children}</div>;
}
