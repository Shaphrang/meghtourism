"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { getBrowserClient } from "@/lib/supabaseClients";

export default function AgencySignup() {
  const supabase = getBrowserClient();
  const router = useRouter();
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr(null); setBusy(true);
    try {
      // 1) name availability (case-insensitive)
      const { data: taken, error: nameErr } = await supabase
        .from("tourism_agencies")
        .select("id").ilike("name", form.name).limit(1);
      if (nameErr) throw nameErr;
      if ((taken?.length ?? 0) > 0) { setErr("Agency name already in use."); return; }

      // 2) sign up (email confirm OFF => session immediately)
      const { data: { user }, error: signErr } = await supabase.auth.signUp({
        email: form.email, password: form.password
      });
      if (signErr) throw signErr;
      if (!user) throw new Error("Signup failed.");

      // 3) create agency row (DB creates slug; RLS requires owner_user_id=auth.uid())
      const { error: insErr } = await supabase.from("tourism_agencies").insert({
        name: form.name, owner_user_id: user.id
      });
      if (insErr && insErr.code !== "23505") throw insErr; // ignore race

      router.replace("/agency");
    } catch (e: any) {
      setErr(e.message ?? "Something went wrong");
    } finally {
      setBusy(false);
    }
  };

  return (
    <main className="mx-auto max-w-md p-6">
      <h1 className="text-xl font-bold">Create your agency</h1>
      <form onSubmit={onSubmit} className="mt-4 space-y-3">
        <Field label="Agency name">
          <input required className="mt-1 w-full rounded-xl border p-2"
                 value={form.name} onChange={e=>setForm({...form, name:e.target.value})}/>
        </Field>
        <Field label="Email">
          <input required type="email" className="mt-1 w-full rounded-xl border p-2"
                 value={form.email} onChange={e=>setForm({...form, email:e.target.value})}/>
        </Field>
        <Field label="Password">
          <input required type="password" className="mt-1 w-full rounded-xl border p-2"
                 value={form.password} onChange={e=>setForm({...form, password:e.target.value})}/>
        </Field>
        {err && <div className="text-rose-600 text-sm">{err}</div>}
        <button disabled={busy} className="w-full rounded-xl bg-gray-900 text-white py-2">
          {busy ? "Creating..." : "Create account"}
        </button>
        <p className="text-xs text-gray-500">Have an account? <a className="underline" href="/agency/login">Log in</a></p>
      </form>
    </main>
  );
}
function Field({ label, children }: any) { return <div><div className="text-sm font-medium">{label}</div>{children}</div>; }
