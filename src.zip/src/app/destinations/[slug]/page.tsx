// src/app/destinations/[slug]/page.tsx
import DestinationDetailPage from './clientPage';

export default function Page() {
  return <DestinationDetailPage />;
}
