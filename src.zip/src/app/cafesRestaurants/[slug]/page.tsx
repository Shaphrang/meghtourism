import ClientPage from './clientPage';

export default function Page() {
  return <ClientPage />;
}
