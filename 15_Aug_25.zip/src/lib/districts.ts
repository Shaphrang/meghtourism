export const DISTRICTS = [
  'East Khasi Hills',
  'West Khasi Hills',
  'South West Khasi Hills',
  'Ri-Bhoi',
  'East Jaintia Hills',
  'West Jaintia Hills',
  'East Garo Hills',
  'West Garo Hills',
  'South Garo Hills',
  'South West Garo Hills',
  'North Garo Hills',
];
