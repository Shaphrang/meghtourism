import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { createServerComponentClient } from "@supabase/auth-helpers-nextjs";
import DashboardClient from "./DashboardClient";

export const dynamic = "force-dynamic";

export default async function AgencyDashboard() {
  const supabase = createServerComponentClient({ cookies });
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/agency/signup");

  const { data: agency } = await supabase
    .from("tourism_agencies")
    .select("id,name,slug,short_description,logo_url,cover_image_url,email,phone,website,gstin,city,district")
    .eq("owner_user_id", user.id)
    .single();

  if (!agency) redirect("/agency/signup");

  const { data: itineraries } = await supabase
    .from("itineraries")
    .select("id,title,days,starting_point,ending_point,approval_status,visibilitystatus,is_active,cover_image_path,updated_at,created_at")
    .eq("provider_id", agency.id)
    .order("updated_at", { ascending: false });

  return <DashboardClient agency={agency} initialItineraries={itineraries ?? []} />;
}
