"use client";
import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs";
import AgencyImageUploader from "./../../../components/agencyImageUploader"; // uses your uploadToSupabase helper :contentReference[oaicite:1]{index=1}

function publicImageUrl(path?: string | null) {
  if (!path) return null;
  const base = process.env.NEXT_PUBLIC_SUPABASE_URL!;
  return `${base}/storage/v1/object/public/images/${encodeURI(path)}`;
}

export default function DashboardClient({
  agency: initialAgency,
  initialItineraries,
}: {
  agency: any;
  initialItineraries: any[];
}) {
  const router = useRouter();
  const supabase = createClientComponentClient();

  const [agency, setAgency] = useState<any>(initialAgency);
  const [desc, setDesc] = useState<string>(initialAgency?.short_description ?? "");
  const [itins, setItins] = useState<any[]>(initialItineraries);
  const [saving, setSaving] = useState(false);

  // ---------- Header actions ----------
  const logout = async () => {
    await supabase.auth.signOut();
    router.replace("/agency/login");
  };

  // ---------- Profile save ----------
  const saveProfile = async () => {
    setSaving(true);
    const payload = {
      short_description: desc || null,
      // these fields are displayed, not all necessarily editable inline — adjust if you want inputs for them:
      email: agency.email || null,
      phone: agency.phone || null,
      website: agency.website || null,
      gstin: agency.gstin || null,
      city: agency.city || null,
      district: agency.district || null,
      logo_url: agency.logo_url || null,
    };
    const { error } = await supabase.from("tourism_agencies").update(payload).eq("id", agency.id);
    setSaving(false);
    if (!error) {
      setAgency({ ...agency, ...payload });
    } else {
      alert(error.message);
    }
  };

  // ---------- Itineraries ----------
  const refreshItins = async () => {
    const { data } = await supabase
      .from("itineraries")
      .select("id,title,days,starting_point,ending_point,approval_status,visibilitystatus,is_active,cover_image_path,updated_at,created_at")
      .eq("provider_id", agency.id)
      .order("updated_at", { ascending: false });
    setItins(data ?? []);
  };

  const createItinerary = async () => {
    const { error } = await supabase.from("itineraries").insert({
      provider_id: agency.id,
      title: "Untitled itinerary",
      description: "",
      days: 1,
      starting_point: "",
      ending_point: "",
      visibilitystatus: "draft",
      is_active: true,
    });
    if (error) return alert(error.message);
    await refreshItins();
  };

  // ---------- Modal state ----------
  const [editing, setEditing] = useState<any | null>(null);

  return (
    <main className="p-6 space-y-6">
      {/* Header */}
      <header className="flex items-center justify-between">
        <div>
          <div className="text-xs text-gray-500">Agency</div>
          <h1 className="text-xl font-bold">{agency.name}</h1>
        </div>
        <div className="flex items-center gap-2">
          <a href="/agency/profile" className="rounded-xl border px-4 py-2 text-sm">Profile</a>
          <button onClick={logout} className="rounded-xl bg-gray-900 text-white px-4 py-2 text-sm">
            Logout
          </button>
        </div>
      </header>

      {/* Profile summary */}
      <section className="rounded-2xl border shadow-sm p-4">
        <div className="flex items-start gap-4">
          <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-3">
            <Row label="Name" value={agency.name} />
            <Row label="Location" value={[agency.city, agency.district].filter(Boolean).join(", ")} />
            <Row label="Phone" value={agency.phone || "—"} />
            <Row label="Email" value={agency.email || "—"} />
            <Row label="Website" value={agency.website || "—"} />
            <Row label="GSTIN" value={agency.gstin || "—"} />
          </div>

          {/* Profile picture (right) */}
          <div className="w-28">
            <div className="text-sm font-medium mb-1">Profile picture</div>
            <div className="rounded-xl border overflow-hidden aspect-square bg-gray-50">
              {agency.logo_url ? (
                <img src={publicImageUrl(agency.logo_url) ?? ""} alt="Logo" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full grid place-items-center text-xs text-gray-500">No image</div>
              )}
            </div>
            <div className="mt-2">
              <AgencyImageUploader
                agencyId={agency.id}
                category="agency"
                rowId={agency.id}
                type="main"
                name={agency.name}
                onUploaded={async (_url, path) => {
                  const { error } = await supabase
                    .from("tourism_agencies")
                    .update({ logo_url: path })
                    .eq("id", agency.id);
                  if (!error) setAgency((a: any) => ({ ...a, logo_url: path }));
                }}
              />
            </div>
          </div>
        </div>

        {/* Description */}
        <div className="mt-4">
          <div className="text-sm font-medium">Description</div>
          <textarea
            className="mt-1 w-full rounded-xl border p-3"
            rows={4}
            placeholder="Tell visitors about your agency…"
            value={desc}
            onChange={(e) => setDesc(e.target.value)}
          />
          <div className="mt-2">
            <button
              onClick={saveProfile}
              disabled={saving}
              className="rounded-xl bg-gray-900 text-white px-4 py-2 text-sm"
            >
              {saving ? "Saving..." : "Save Profile"}
            </button>
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <h2 className="text-xs font-semibold tracking-wider text-gray-500">SERVICES</h2>

      {/* Itineraries */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="text-lg font-semibold">Itineraries</div>
          <button
            onClick={createItinerary}
            className="rounded-xl bg-gray-900 text-white px-4 py-2 text-sm"
          >
            Create Itinerary
          </button>
        </div>

        <ul className="grid gap-3">
          {itins.map((it) => (
            <li key={it.id} className="rounded-2xl border shadow-sm p-3 flex items-center gap-3">
              <div className="w-16 h-16 rounded-xl bg-gray-50 overflow-hidden">
                {it.cover_image_path ? (
                  <img
                    src={publicImageUrl(it.cover_image_path) ?? ""}
                    alt=""
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full grid place-items-center text-xs text-gray-500">No image</div>
                )}
              </div>

              <button
                className="flex-1 text-left"
                onClick={() => setEditing(it)}
                title="Edit itinerary"
              >
                <div className="font-medium line-clamp-1">{it.title || "Untitled itinerary"}</div>
                <div className="text-xs text-gray-600 line-clamp-1">
                  {(it.days || 0) > 0 ? `${it.days} day${it.days>1?"s":""}` : "—"} · {it.starting_point || "—"} → {it.ending_point || "—"}
                </div>
                <div className="text-[11px] text-gray-500">
                  Updated {new Date(it.updated_at ?? it.created_at).toLocaleString()}
                </div>
              </button>

              <div className="text-right">
                <span className="inline-block rounded-full text-xs px-2 py-1 border">
                  {it.approval_status || "pending"}
                </span>
                <div className="mt-2 flex justify-end">
                  <button
                    className="text-xs rounded-lg border px-2 py-1"
                    onClick={() => setEditing(it)}
                  >
                    Edit
                  </button>
                </div>
              </div>
            </li>
          ))}
          {itins.length === 0 && (
            <li className="text-sm text-gray-600">No itineraries yet. Create your first itinerary.</li>
          )}
        </ul>
      </section>

      {/* Modal */}
      {editing && (
        <ItineraryModal
          agencyId={agency.id}
          row={editing}
          onClose={() => setEditing(null)}
          onSaved={async () => {
            setEditing(null);
            await refreshItins();
          }}
        />
      )}
    </main>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border p-3">
      <div className="text-[11px] uppercase tracking-wide text-gray-500">{label}</div>
      <div className="text-sm mt-1">{value || "—"}</div>
    </div>
  );
}

/* ---------- Modal for editing an itinerary ---------- */
function ItineraryModal({
  agencyId,
  row,
  onClose,
  onSaved,
}: {
  agencyId: string;
  row: any;
  onClose: () => void;
  onSaved: () => void;
}) {
  const supabase = createClientComponentClient();
  const [form, setForm] = useState<any>({
    title: row.title || "",
    days: row.days || 1,
    starting_point: row.starting_point || "",
    ending_point: row.ending_point || "",
    visibilitystatus: row.visibilitystatus || "draft",
    is_active: !!row.is_active,
    contact: row.contact || "",
    email: row.email || "",
    website: row.website || "",
    cover_image_path: row.cover_image_path || null,
  });
  const [saving, setSaving] = useState(false);

  const save = async () => {
    setSaving(true);
    const payload = {
      title: form.title,
      days: Number(form.days) || 1,
      starting_point: form.starting_point,
      ending_point: form.ending_point,
      visibilitystatus: form.visibilitystatus,
      is_active: !!form.is_active,
      contact: form.contact || null,
      email: form.email || null,
      website: form.website || null,
      cover_image_path: form.cover_image_path || null,
      // do NOT allow agency to change approval_status (admin-only)
    };
    const { error } = await supabase.from("itineraries").update(payload).eq("id", row.id);
    setSaving(false);
    if (error) return alert(error.message);
    onSaved();
  };

  const imgUrl = useMemo(() => publicImageUrl(form.cover_image_path), [form.cover_image_path]);

  return (
    <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm grid place-items-center p-4">
      <div className="w-full max-w-2xl rounded-2xl bg-white shadow-xl">
        <div className="p-4 border-b flex items-center justify-between">
          <div className="text-lg font-semibold">Edit Itinerary</div>
          <button className="text-sm px-3 py-1 rounded-lg border" onClick={onClose}>Close</button>
        </div>

        <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-3">
          <Field label="Title">
            <input className="w-full rounded-xl border p-2"
              value={form.title} onChange={(e)=>setForm({...form, title: e.target.value})}/>
          </Field>
          <Field label="Days">
            <input type="number" min={1} className="w-full rounded-xl border p-2"
              value={form.days} onChange={(e)=>setForm({...form, days: e.target.value})}/>
          </Field>
          <Field label="Starting point">
            <input className="w-full rounded-xl border p-2"
              value={form.starting_point} onChange={(e)=>setForm({...form, starting_point: e.target.value})}/>
          </Field>
          <Field label="Ending point">
            <input className="w-full rounded-xl border p-2"
              value={form.ending_point} onChange={(e)=>setForm({...form, ending_point: e.target.value})}/>
          </Field>
          <Field label="Visibility">
            <select className="w-full rounded-xl border p-2"
              value={form.visibilitystatus} onChange={(e)=>setForm({...form, visibilitystatus: e.target.value})}>
              <option value="draft">Draft</option>
              <option value="hidden">Hidden</option>
              <option value="visible">Visible</option>
            </select>
          </Field>
          <Field label="Active?">
            <label className="inline-flex items-center gap-2 text-sm">
              <input type="checkbox" checked={!!form.is_active}
                onChange={(e)=>setForm({...form, is_active: e.target.checked})}/>
              <span>Is active</span>
            </label>
          </Field>

          <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-3 gap-3">
            <Field label="Contact"><input className="w-full rounded-xl border p-2"
              value={form.contact} onChange={(e)=>setForm({...form, contact: e.target.value})}/></Field>
            <Field label="Email"><input className="w-full rounded-xl border p-2"
              value={form.email} onChange={(e)=>setForm({...form, email: e.target.value})}/></Field>
            <Field label="Website"><input className="w-full rounded-xl border p-2"
              value={form.website} onChange={(e)=>setForm({...form, website: e.target.value})}/></Field>
          </div>

          <div className="md:col-span-2">
            <div className="text-sm font-medium">Cover image</div>
            <div className="mt-1 flex items-center gap-3">
              <div className="w-28 h-28 rounded-xl border overflow-hidden bg-gray-50">
                {imgUrl ? <img src={imgUrl} className="w-full h-full object-cover" alt=""/> :
                  <div className="w-full h-full grid place-items-center text-xs text-gray-500">No image</div>}
              </div>
              <AgencyImageUploader
                agencyId={agencyId}
                category="itineraries"
                rowId={row.id}
                type="main"
                name={form.title || "itinerary"}
                onUploaded={async (_url, path) => {
                  setForm((f: any) => ({ ...f, cover_image_path: path }));
                }}
              />
            </div>
          </div>
        </div>

        <div className="p-4 border-t flex justify-end gap-2">
          <button className="rounded-xl border px-4 py-2" onClick={onClose}>Cancel</button>
          <button
            className="rounded-xl bg-gray-900 text-white px-4 py-2"
            onClick={save}
            disabled={saving}
          >
            {saving ? "Saving..." : "Save changes"}
          </button>
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="text-sm font-medium">{label}</div>
      <div className="mt-1">{children}</div>
    </div>
  );
}
