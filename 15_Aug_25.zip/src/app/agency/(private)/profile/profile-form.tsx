"use client";
import { useState } from "react";
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs";

export default function ProfileForm({ agency }: { agency: any }) {
  const supabase = createClientComponentClient();
  const [form, setForm] = useState(agency ?? {});
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  const save = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true); setMsg(null);
    const payload = {
      short_description: form.short_description ?? null,
      about: form.about ?? null,
      logo_url: form.logo_url ?? null,
      cover_image_url: form.cover_image_url ?? null,
      email: form.email ?? null, phone: form.phone ?? null, whatsapp: form.whatsapp ?? null, website: form.website ?? null,
      address: form.address ?? null, city: form.city ?? null, district: form.district ?? null, pincode: form.pincode ?? null,
      gstin: form.gstin ?? null, years_in_service: form.years_in_service ? Number(form.years_in_service) : null,
      social: form.social || null, show_public_profile: !!form.show_public_profile,
    };
    const { error } = await supabase.from("tourism_agencies").update(payload).eq("id", agency.id);
    setBusy(false);
    setMsg(error ? error.message : "Saved.");
  };

  return (
    <main className="mx-auto max-w-2xl p-6 space-y-4">
      <h1 className="text-xl font-bold">Agency profile</h1>
      <Read label="Name" value={agency?.name} />
      <Read label="Slug" value={agency?.slug} />
      <Field label="Short description"><textarea className="w-full rounded-xl border p-2" rows={2}
        value={form.short_description||""} onChange={e=>setForm({...form,short_description:e.target.value})}/></Field>
      <Field label="About"><textarea className="w-full rounded-xl border p-2" rows={6}
        value={form.about||""} onChange={e=>setForm({...form,about:e.target.value})}/></Field>

      <div className="grid grid-cols-2 gap-3">
        <Field label="Logo URL"><input className="w-full rounded-xl border p-2"
          value={form.logo_url||""} onChange={e=>setForm({...form,logo_url:e.target.value})}/></Field>
        <Field label="Cover Image URL"><input className="w-full rounded-xl border p-2"
          value={form.cover_image_url||""} onChange={e=>setForm({...form,cover_image_url:e.target.value})}/></Field>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <Field label="Email"><input className="w-full rounded-xl border p-2" value={form.email||""} onChange={e=>setForm({...form,email:e.target.value})}/></Field>
        <Field label="Phone"><input className="w-full rounded-xl border p-2" value={form.phone||""} onChange={e=>setForm({...form,phone:e.target.value})}/></Field>
        <Field label="WhatsApp"><input className="w-full rounded-xl border p-2" value={form.whatsapp||""} onChange={e=>setForm({...form,whatsapp:e.target.value})}/></Field>
        <Field label="Website"><input className="w-full rounded-xl border p-2" value={form.website||""} onChange={e=>setForm({...form,website:e.target.value})}/></Field>
      </div>

      <Field label="Address"><input className="w-full rounded-xl border p-2" value={form.address||""} onChange={e=>setForm({...form,address:e.target.value})}/></Field>
      <div className="grid grid-cols-3 gap-3">
        <Field label="City"><input className="w-full rounded-xl border p-2" value={form.city||""} onChange={e=>setForm({...form,city:e.target.value})}/></Field>
        <Field label="District"><input className="w-full rounded-xl border p-2" value={form.district||""} onChange={e=>setForm({...form,district:e.target.value})}/></Field>
        <Field label="Pincode"><input className="w-full rounded-xl border p-2" value={form.pincode||""} onChange={e=>setForm({...form,pincode:e.target.value})}/></Field>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <Field label="GSTIN"><input className="w-full rounded-xl border p-2" value={form.gstin||""} onChange={e=>setForm({...form,gstin:e.target.value})}/></Field>
        <Field label="Years in service"><input type="number" min={0} className="w-full rounded-xl border p-2" value={form.years_in_service||""}
          onChange={e=>setForm({...form,years_in_service:e.target.value})}/></Field>
      </div>

      <label className="flex items-center gap-2">
        <input type="checkbox" checked={!!form.show_public_profile}
               onChange={e=>setForm({...form,show_public_profile:e.target.checked})}/>
        <span className="text-sm">Show my profile publicly later</span>
      </label>

      <div className="flex items-center gap-2">
        <button disabled={busy} className="rounded-xl bg-gray-900 text-white px-4 py-2">
          {busy ? "Saving..." : "Save"}
        </button>
        {msg && <span className="text-sm text-emerald-700">{msg}</span>}
      </div>
    </main>
  );
}
function Field({ label, children }: any) { return <div><div className="text-sm font-medium">{label}</div><div className="mt-1">{children}</div></div>; }
function Read({ label, value }: any) { return <div><div className="text-sm font-medium">{label}</div><div className="mt-1 rounded-xl border bg-gray-50 p-2 text-sm">{value}</div></div>; }
